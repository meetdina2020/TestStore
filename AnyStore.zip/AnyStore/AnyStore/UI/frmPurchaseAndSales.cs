﻿using AnyStore.BLL;
using AnyStore.DAL;
using DGVPrinterHelper;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;

using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;
using System.Web;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System.Configuration;
using System.IO;

using System.Net;
using System.Net.Mail;
using System.Diagnostics;
using System.Text;
using iTextSharp.text.html;
using iTextSharp.text.pdf.draw;

namespace AnyStore.UI
{
    public partial class frmPurchaseAndSales : Form
    {
        public frmPurchaseAndSales()
        {
            InitializeComponent();
        }

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        DeaCustDAL dcDAL = new DeaCustDAL();
        productsDAL pDAL = new productsDAL();
        userDAL uDAL = new userDAL();
        transactionDAL tDAL = new transactionDAL();
        transactionDetailDAL tdDAL = new transactionDetailDAL();

        public DataTable transactionDT = new DataTable();
        private void frmPurchaseAndSales_Load(object sender, EventArgs e)
        {
            //Get the transactionType value from frmUserDashboard
            string type = frmUserDashboard.transactionType;
            //Set the value on lblTop
            lblTop.Text = type;

            //Specify Columns for our TransactionDataTable
            transactionDT.Columns.Add("Product Name");
            transactionDT.Columns.Add("Rate");
            transactionDT.Columns.Add("Quantity");
            transactionDT.Columns.Add("Total");
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //Get the keyword fro the text box
            string keyword = "";

            if (keyword == "")
            {
                //Clear all the textboxes
                txtName1.Text = "";
                txtGSTIN1.Text = "";
                txtState1.Text = "";
                txtAddress1.Text = "";
                return;
            }

            //Write the code to get the details and set the value on text boxes
            DeaCustBLL dc = dcDAL.SearchDealerCustomerForTransaction(keyword);

            //Now transfer or set the value from DeCustBLL to textboxes
            txtName1.Text = dc.name;
            txtGSTIN1.Text = dc.email;
            txtState1.Text = dc.contact;
            txtAddress1.Text = dc.address;
        }

        private void txtSearchProduct_TextChanged(object sender, EventArgs e)
        {

            //Get the keyword from productsearch textbox
            string keyword = txtSearchProduct.Text;

            //Check if we have value to txtSearchProduct or not
            if (keyword == "")
            {
                txtProductName.Text = "";
                txtInventory.Text = "";
                txtRate.Text = "";
                TxtQty.Text = "";
                return;
            }

            //Search the product and display on respective textboxes
            productsBLL p = pDAL.GetProductsForTransaction(keyword);

            //Set the values on textboxes based on p object
            txtProductName.Text = p.name;
            txtInventory.Text = p.qty.ToString();
            txtRate.Text = p.rate.ToString();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            //Get Product Name, Rate and Qty customer wants to buy
            string productName = txtProductName.Text;
            decimal Rate = decimal.Parse(txtRate.Text);
            decimal Qty = decimal.Parse(TxtQty.Text);

            decimal Total = Rate * Qty; //Total=RatexQty

            //Display the Subtotal in textbox
            //Get the subtotal value from textbox
            decimal subTotal = decimal.Parse(txtSubTotal.Text);
            subTotal = subTotal + Total;
            // CGST 12%
            //Calculate the grandtotal based on discount

            //Check whether the product is selected or not
            if (productName == "")
            {
                //Display error MEssage
                MessageBox.Show("Select the product first. Try Again.");
            }
            else
            {
                GSTBLL gstBLL = dcDAL.GetGSTDetails();
                //Add product to the dAta Grid View
                transactionDT.Rows.Add(productName, Rate, Qty, Total);

                //Show in DAta Grid View
                dgvAddedProducts.DataSource = transactionDT;
                //Display the Subtotal in textbox
                txtSubTotal.Text = subTotal.ToString();
                decimal previousGT = decimal.Parse(txtSubTotal.Text);
                decimal cgst = gstBLL.cgst;
                decimal sgst = gstBLL.sgst;
                decimal igst = gstBLL.igst;
                decimal cgstAmount = (previousGT / 100) * cgst;
                decimal sgstAmount = (previousGT / 100) * sgst;
                decimal igstAmount = (previousGT / 100) * igst;
                txtCGST.Text = cgstAmount.ToString();
                txtSGST.Text = sgstAmount.ToString();
                txtIGST.Text = igstAmount.ToString();
                txtTotalTaxAmount.Text = ((cgstAmount + sgstAmount) - igstAmount).ToString();
                decimal grandTotalWithVAT = ((100 + ((cgst + sgst) - igst)) / 100) * previousGT;

                //Displaying new grand total with vat
                
                txtGrandTotal.Text = Math.Round(decimal.Parse(grandTotalWithVAT.ToString()), 2).ToString();
                //Clear the Textboxes
                txtSearchProduct.Text = "";
                txtProductName.Text = "";
                txtInventory.Text = "0.00";
                txtRate.Text = "0.00";
                TxtQty.Text = "0.00";
            }
        }

        //private void txtDiscount_TextChanged(object sender, EventArgs e)
        //{
        //    //Get the value fro discount textbox
        //    string value = txtDiscount.Text;

        //    if(value=="")
        //    {
        //        //Display Error Message
        //        MessageBox.Show("Please Add Discount First");
        //    }
        //    else
        //    {
        //        //Get the discount in decimal value
        //        decimal subTotal = decimal.Parse(txtSubTotal.Text);
        //        decimal discount = decimal.Parse(txtDiscount.Text);

        //        //Calculate the grandtotal based on discount
        //        decimal grandTotal = ((100 - discount) / 100) * subTotal;

        //        //Display the GrandTotla in TextBox
        //        txtGrandTotal.Text = grandTotal.ToString();
        //    }

        //}

        private void txtVat_TextChanged(object sender, EventArgs e)
        {
            ////Check if the grandTotal has value or not if it has not value then calculate the discount first
            //string check = txtGrandTotal.Text;
            //if(check=="")
            //{
            //    //Deisplay the error message to calcuate discount
            //    MessageBox.Show("Calculate the discount and set the Grand Total First.");
            //}
            //else
            //{
            //    //Calculate VAT
            //    //Getting the VAT Percent first
            //    decimal previousGT = decimal.Parse(txtGrandTotal.Text);
            //    decimal vat = decimal.Parse(txtIGST.Text);
            //    decimal grandTotalWithVAT=((100+vat)/100)*previousGT;

            //    //Displaying new grand total with vat
            //    txtGrandTotal.Text = grandTotalWithVAT.ToString();
            //}
        }

        private void txtPaidAmount_TextChanged(object sender, EventArgs e)
        {
            ////Get the paid amount and grand total
            //decimal grandTotal = decimal.Parse(txtGrandTotal.Text);
            //decimal paidAmount = decimal.Parse(txtPaidAmount.Text);

            //decimal returnAmount = paidAmount - grandTotal;

            ////Display the return amount as well
            //txtReturnAmount.Text = returnAmount.ToString();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //Get the Values from PurchaseSales Form First
            transactionsBLL transaction = new transactionsBLL();

            transaction.type = lblTop.Text;

            //Get the ID of Dealer or Customer Here
            //Lets get name of the dealer or customer first
            string deaCustName = txtName1.Text;
            DeaCustBLL dc = dcDAL.GetDeaCustIDFromName(deaCustName);


            transaction.dea_cust_id = dc.id;
            transaction.grandTotal = Math.Round(decimal.Parse(txtGrandTotal.Text), 2);
            transaction.transaction_date = DateTime.Now;
            transaction.tax = decimal.Parse(txtIGST.Text);
            transaction.discount = 0;
            transaction.invoice_date = DateTime.Now;
            transaction.name1 = txtName1.Text.Trim();
            transaction.gstin1 = txtGSTIN1.Text.Trim();
            transaction.address1 = txtAddress1.Text.Trim();
            transaction.state1 = txtState1.Text.Trim();
            transaction.state_code1 = "33";
            transaction.consignee_shipped_to = txtDetailShipped.Text.Trim();
            transaction.transportation_mode = txtTransMode.Text.Trim();
            transaction.vehicle_no = txtVehicleNo.Text.Trim();
            transaction.name2 = txtName2.Text.Trim();
            transaction.address2 = txtAddress2.Text.Trim();
            transaction.gstin2 = txtGSTIN2.Text.Trim();
            transaction.state2 = txtState2.Text.Trim();
            transaction.state_code2 = "";
            //Get the Username of Logged in user
            string username = frmLogin.loggedIn;
            userBLL u = uDAL.GetIDFromUsername(username);

            transaction.added_by = u.id;
            transaction.transactionDetails = transactionDT;

            //Lets Create a Boolean Variable and set its value to false
            bool success = false;

            //Actual Code to Insert Transaction And Transaction Details
            using (TransactionScope scope = new TransactionScope())
            {
                int transactionID = -1;
                //Create aboolean value and insert transaction 
                bool w = tDAL.Insert_Transaction(transaction, out transactionID);

                //Use for loop to insert Transaction Details
                for (int i = 0; i < transactionDT.Rows.Count; i++)
                {
                    //Get all the details of the product
                    transactionDetailBLL transactionDetail = new transactionDetailBLL();
                    //Get the Product name and convert it to id
                    string ProductName = transactionDT.Rows[i][0].ToString();
                    productsBLL p = pDAL.GetProductIDFromName(ProductName);

                    transactionDetail.product_id = p.id;
                    transactionDetail.rate = decimal.Parse(transactionDT.Rows[i][1].ToString());
                    transactionDetail.qty = decimal.Parse(transactionDT.Rows[i][2].ToString());
                    transactionDetail.total = Math.Round(decimal.Parse(transactionDT.Rows[i][3].ToString()), 2);
                    transactionDetail.dea_cust_id = dc.id;
                    transactionDetail.added_date = DateTime.Now;
                    transactionDetail.added_by = u.id;

                    //Here Increase or Decrease Product Quantity based on Purchase or sales
                    string transactionType = lblTop.Text;

                    //Lets check whether we are on Purchase or Sales
                    //bool x=false;
                    //if(transactionType=="Purchase")
                    //{
                    //    //Increase the Product
                    //    x = pDAL.IncreaseProduct(transactionDetail.product_id, transactionDetail.qty);
                    //}
                    //else if(transactionType=="Sales")
                    //{
                    //    //Decrease the Product Quntiyt
                    //    x = pDAL.DecreaseProduct(transactionDetail.product_id, transactionDetail.qty);
                    //}

                    //Insert Transaction Details inside the database
                    bool y = tdDAL.InsertTransactionDetail(transactionDetail);
                    success = w && y;
                }

                if (success == true)
                {
                    //sb.Append("<div ><h5>GSTIN:33AKFPM4759B1ZC</h5></div>");
                    //sb.Append("<div style='text - align: center'><h1>Aruna Trading Company</h1></div>");
                    //sb.Append("<div style='text - align: cente'><h3>Manufactures of Thirumanjana Powder,Kaduga Powder, Kumkum, Vibuthi Powder</h3></div>");
                    //sb.Append("<div style='text - align: center'><h3>No 14/17A, Annamalai street, Swaminathapuram, SALEM-9</h3></div>");
                    //sb.Append("<div style='text - align: center'><h3>Tax Invoice</h3></div>");
                    //sb.Append("</body>");
                    //sb.Append("</html>");

                    #region Common Part
                    var normalFont = FontFactory.GetFont(FontFactory.HELVETICA, 10);
                    PdfPTable pdfTableBlank = new PdfPTable(1);
                    //Footer Section
                    PdfPTable pdfTableFooter = new PdfPTable(1);
                    pdfTableFooter.DefaultCell.BorderWidth = 0;
                    pdfTableFooter.WidthPercentage = 100;
                    pdfTableFooter.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;
                    Chunk cnkFooter = new Chunk("Aruna Trading Company", FontFactory.GetFont("Times New Roman"));
                    //cnkFooter.Font.SetStyle(1);
                    cnkFooter.Font.Size = 10;
                    pdfTableFooter.AddCell(new Phrase(cnkFooter));
                    //End Of Footer Section
                    pdfTableBlank.AddCell(new Phrase(" "));
                    pdfTableBlank.DefaultCell.BorderWidth = 0;
                    #endregion
                    #region Page
                    #region Section-1 <Header FORM>
                    PdfPTable pdfTable1 = new PdfPTable(1);//Here 1 is Used For Count of Column
                    PdfPTable pdfTable2 = new PdfPTable(1);
                    PdfPTable pdfTable3 = new PdfPTable(5);
                    //Font Style
                    System.Drawing.Font fontH1 = new System.Drawing.Font("Currier", 10);
                    //pdfTable1.DefaultCell.Padding = 5;
                    pdfTable1.WidthPercentage = 80;
                    pdfTable1.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;
                    pdfTable1.DefaultCell.VerticalAlignment = Element.ALIGN_CENTER;
                    //pdfTable1.DefaultCell.BackgroundColor = new iTextSharp.text.BaseColor(64, 134, 170);
                    pdfTable1.DefaultCell.BorderWidth = 0;
                    //pdfTable1.DefaultCell.Padding = 5;
                    pdfTable2.WidthPercentage = 80;
                    pdfTable2.DefaultCell.HorizontalAlignment = Element.ALIGN_CENTER;
                    pdfTable2.DefaultCell.VerticalAlignment = Element.ALIGN_CENTER;
                    //pdfTab2e1.DefaultCell.BackgroundColor = new iTextSharp.text.BaseColor(64, 134, 170);
                    pdfTable2.DefaultCell.BorderWidth = 0;
                    pdfTable3.DefaultCell.Padding = 5;
                    pdfTable3.WidthPercentage = 95;
                    pdfTable3.DefaultCell.BorderWidth = 0.5f;
                   
                    Chunk c1 = new Chunk("Aruna Trading Company", FontFactory.GetFont("Times New Roman"));
                    c1.Font.Color = new iTextSharp.text.BaseColor(0, 0, 0);
                    c1.Font.SetStyle(0);
                    c1.Font.Size = 14;
                    Phrase p1 = new Phrase();
                    p1.Add(c1);
                    pdfTable1.AddCell(p1);
                    Chunk c2 = new Chunk("Manufactures of Thirumanjana Powder,Kaduga Powder, Kumkum, Vibuthi Powder", FontFactory.GetFont("Times New Roman"));
                    c2.Font.Color = new iTextSharp.text.BaseColor(0, 0, 0);
                    c2.Font.SetStyle(0);//0 For Normal Font
                    c2.Font.Size = 11;
                    Phrase p2 = new Phrase();
                    p2.Add(c2);
                    pdfTable2.AddCell(p2);
                    Chunk c3 = new Chunk("No 14/17A, Annamalai street, Swaminathapuram, SALEM-9", FontFactory.GetFont("Times New Roman"));
                    c3.Font.Color = new iTextSharp.text.BaseColor(0, 0, 0);
                    c3.Font.SetStyle(0);
                    c3.Font.Size = 11;
                    Phrase p3 = new Phrase();
                    p3.Add(c3);
                    pdfTable2.AddCell(p3);

                    Chunk c4 = new Chunk("Tax Invoice", FontFactory.GetFont("Times New Roman"));
                    c4.Font.Color = new iTextSharp.text.BaseColor(0, 0, 0);
                    c4.SetBackground(new BaseColor(224, 224, 224));
                    c4.Font.SetStyle(0);
                    c4.Font.Size = 11;
                    Phrase p4 = new Phrase();
                    p4.Add(c4);
                    pdfTable2.AddCell(p4);
                    Chunk linebreak = new Chunk(new LineSeparator(1f, 95, BaseColor.LIGHT_GRAY, Element.ALIGN_CENTER, -1));
                    Phrase p5 = new Phrase();
                    p5.Add(linebreak);
                    
                    #endregion
                    #region Section-1 <Bill Upper>
                    PdfPTable pdfTable4 = new PdfPTable(4);
                    pdfTable4.DefaultCell.Padding = 3;
                    pdfTable4.DefaultCell.Border = 0;
                    pdfTable4.WidthPercentage = 95;
                  
                    pdfTable4.AddCell(new Phrase("Invoice No",normalFont));
                   
                    pdfTable4.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable4.AddCell(new Phrase("Details of Consignee Shipped to ", normalFont));
                    pdfTable4.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable4.AddCell(new Phrase("Invoice Date ", normalFont));
                    pdfTable4.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable4.AddCell(new Phrase("Transportation Mode ", normalFont));
                    pdfTable4.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable4.AddCell(new Phrase("State: Tamil Nade", normalFont));
                    pdfTable4.AddCell(new Phrase("State Code:33", normalFont));
                    pdfTable4.AddCell(new Phrase("Vehicle No", normalFont));
                    pdfTable4.AddCell(new Phrase("XXXX", normalFont));
                    Chunk linebreak1 = new Chunk(new LineSeparator(1f, 95, BaseColor.LIGHT_GRAY, Element.ALIGN_CENTER, -1));
                    Phrase p6 = new Phrase();
                    p6.Add(linebreak1);
                  


                    PdfPTable pdfTable5 = new PdfPTable(4);
                    pdfTable5.DefaultCell.Padding = 3;
                    pdfTable5.DefaultCell.Border = 0;
                    pdfTable5.WidthPercentage = 95;
                    pdfTable5.DefaultCell.BorderWidth = 0.3f;
                   
                    pdfTable5.AddCell(new Phrase("Name", normalFont));
                    pdfTable5.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable5.AddCell(new Phrase("Name", normalFont));
                    pdfTable5.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable5.AddCell(new Phrase("Address", normalFont));
                    pdfTable5.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable5.AddCell(new Phrase("Address", normalFont));
                    pdfTable5.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable5.AddCell(new Phrase("GSTIN", normalFont));
                    pdfTable5.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable5.AddCell(new Phrase("GSTIN", normalFont));
                    pdfTable5.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable5.AddCell(new Phrase("State", normalFont));
                    pdfTable5.AddCell(new Phrase("XXXX", normalFont));
                    pdfTable5.AddCell(new Phrase("State", normalFont));
                    pdfTable5.AddCell(new Phrase("XXXX", normalFont));
                    Paragraph paragraphTable2 = new Paragraph();
                    paragraphTable2.SpacingAfter = 15f;
                    paragraphTable2.Add(pdfTable5);
                    #endregion
                    PdfPTable table = new PdfPTable(7);
                    table.DefaultCell.Border = 0;
                    table.WidthPercentage = 95;
                    PdfPCell cell1 = new PdfPCell(new Phrase("Product Name", normalFont));
                    cell1.Border = 0;
                    cell1.Colspan = 4;
                    
                    cell1.BackgroundColor = new iTextSharp.text.BaseColor(224, 224, 224);
                    table.AddCell(cell1);
                    cell1 = new PdfPCell(new Phrase("Rate", normalFont));
                    cell1.BackgroundColor = new iTextSharp.text.BaseColor(224,224,224);
                    cell1.Border = 0;
                    table.AddCell(cell1);
                    cell1 = new PdfPCell(new Phrase("QTY", normalFont));
                    cell1.BackgroundColor = new iTextSharp.text.BaseColor(224, 224, 224);
                    cell1.Border = 0;
                    table.AddCell(cell1);
                    cell1 = new PdfPCell(new Phrase("Total", normalFont));
                    cell1.BackgroundColor = new iTextSharp.text.BaseColor(224, 224, 224);
                    cell1.Border = 0;
                    table.AddCell(cell1);
                   
                    for (int i = 0; i < transactionDT.Rows.Count; i++)
                    {
                        cell1 = new PdfPCell(new Phrase(transactionDT.Rows[i][0].ToString(), normalFont));
                        cell1.Border = 0;
                        cell1.Colspan = 4;
                        table.AddCell(cell1);
                        table.AddCell(new Phrase(transactionDT.Rows[i][1].ToString(), normalFont));
                        table.AddCell(new Phrase(transactionDT.Rows[i][2].ToString(), normalFont));
                        cell1 = new PdfPCell(new Phrase(transactionDT.Rows[i][3].ToString(), normalFont));
                        cell1.Border = 0;
                        cell1.HorizontalAlignment = Element.ALIGN_RIGHT;
                        table.AddCell(cell1);
                       
                    }
                    Paragraph paragraphTable1 = new Paragraph();
                    paragraphTable1.SpacingAfter = 15f;
                    paragraphTable1.Add(table);
                    //#region Section-Image
                    //string imageURL = @"C:\Users\dkalyanasundaram\Pictures\Camera Roll\Lap.jpg";
                    //iTextSharp.text.Image jpg = iTextSharp.text.Image.GetInstance(imageURL);
                    ////Resize image depend upon your need
                    //jpg.ScaleToFit(140f, 120f);
                    ////Give space before image
                    //jpg.SpacingBefore = 10f;
                    ////Give some space after the image
                    //jpg.SpacingAfter = 1f;
                    //jpg.Alignment = Element.ALIGN_CENTER;
                    //#endregion
                   
                    PdfPCell cell = new PdfPCell(new Phrase(""));
                    cell.Colspan = 3;
                    cell.BorderWidth = 0;
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase("Total Amount Before Tax:",normalFont));
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase(txtSubTotal.Text, normalFont));
                    cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                    pdfTable3.AddCell(cell);

                    cell = new PdfPCell(new Phrase(""));
                    cell.BorderWidth = 0;
                    cell.Colspan = 3;
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase("CGST:", normalFont));

                    pdfTable3.AddCell(cell);

                    cell = new PdfPCell(new Phrase(txtCGST.Text, normalFont));
                    cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                    pdfTable3.AddCell(cell);



                    cell = new PdfPCell(new Phrase(""));
                    cell.Colspan = 3;
                    cell.BorderWidth = 0;
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase("SGST:", normalFont));
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase(txtSGST.Text, normalFont));
                    cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase("BANK Ac No: 61110865490", normalFont));
                    cell.Colspan = 3;
                    cell.BorderWidth = 0;
                    pdfTable3.AddCell(cell);
                   
                    cell = new PdfPCell(new Phrase("IGST:", normalFont));
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase(txtIGST.Text, normalFont));
                    cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase(""));
                    cell.Colspan = 3;
                    cell.BorderWidth = 0;
                    pdfTable3.AddCell(cell);
                  
                    cell = new PdfPCell(new Phrase("Total Tax Amount:", normalFont));
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase(txtTotalTaxAmount.Text, normalFont));
                    cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase("IFSC No: KKBK12345R", normalFont));
                    cell.Colspan = 3;
                    cell.BorderWidth = 0;
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase("Total Amount after Tax:", normalFont));
                    pdfTable3.AddCell(cell);
                    cell = new PdfPCell(new Phrase(txtGrandTotal.Text, normalFont));
                    cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                    pdfTable3.AddCell(cell);




                    PdfPTable pdfTableBottom = new PdfPTable(2);
                    pdfTableBottom.DefaultCell.Padding = 10;
                    pdfTableBottom.WidthPercentage = 95;
                    pdfTableBottom.DefaultCell.Border = 0;
                    
                    cell = new PdfPCell(new Phrase("Total Invoice Amount in Words:", normalFont));
                    cell.BorderWidth = 0;
                    cell.PaddingBottom = 24;
                    pdfTableBottom.AddCell(cell);
                    cell = new PdfPCell(new Phrase("For ARUNA TRADING COMPANY", normalFont));
                    cell.BorderWidth = 0;
                    cell.PaddingBottom = 24;
                    cell.HorizontalAlignment= Element.ALIGN_RIGHT;
                    pdfTableBottom.AddCell(cell);
                    cell = new PdfPCell(new Phrase("E & OE Subject to Salem Jurisdiction", normalFont));
                    cell.BorderWidth = 0;
                    pdfTableBottom.AddCell(cell);
                    cell = new PdfPCell(new Phrase("Authorised Signature", normalFont));
                    cell.BorderWidth = 0;
                    cell.HorizontalAlignment = Element.ALIGN_RIGHT;
                    pdfTableBottom.AddCell(cell);

                    //pdfTable3.AddCell(new Phrase("CGST:"));
                    //pdfTable3.AddCell(new Phrase(txtCGST.Text));
                    //pdfTable3.AddCell(new Phrase("SGST:"));
                    //pdfTable3.AddCell(new Phrase(txtSGST.Text));
                    //pdfTable3.AddCell(new Phrase("IGST:"));
                    //pdfTable3.AddCell(new Phrase(txtIGST.Text));
                    //pdfTable3.AddCell(new Phrase("Total Tax Amount:"));
                    //pdfTable3.AddCell(new Phrase(txtTotalTaxAmount.Text));
                    //pdfTable3.AddCell(new Phrase("Total Amount after Tax:"));
                    //pdfTable3.AddCell(new Phrase(txtGrandTotal.Text));


                    //PdfPTable tablex = new PdfPTable(3);

                    //PdfPCell cell = new PdfPCell(new Phrase("Row 1, Col 1"));
                    //tablex.AddCell(cell);
                    //cell = new PdfPCell(new Phrase("Row 1, Col 2"));
                    //tablex.AddCell(cell);
                    //cell = new PdfPCell(new Phrase("Row 1, Col 3"));
                    //tablex.AddCell(cell);



                    //cell = new PdfPCell(new Phrase("Row 2 and row 3, Col 2 and Col 3"));
                    //cell.Rowspan = 2;
                    //cell.Colspan = 2;
                    //tablex.AddCell(cell);
                    //cell = new PdfPCell(new Phrase("Row 2 ,Col 1"));
                    //tablex.AddCell(cell);

                    //cell = new PdfPCell(new Phrase("Row 3, Col 1"));
                    //tablex.AddCell(cell);



                    #region Pdf Generation
                    string folderPath = "C:\\PDF\\";
                    if (!Directory.Exists(folderPath))
                    {
                        Directory.CreateDirectory(folderPath);
                    }
                    //File Name
                    int fileCount = Directory.GetFiles(@"C:\\PDF").Length;
                    string strFileName = "DescriptionForm" + (fileCount + 1) + ".pdf";
                    using (FileStream stream = new FileStream(folderPath + strFileName, FileMode.Create))
                    {
                        Document pdfDoc = new Document(PageSize.A4, 40f, 10f, 10f, 0f);
                        PdfWriter.GetInstance(pdfDoc, stream);
                        pdfDoc.Open();
                        #region PAGE-1
                        pdfDoc.Add(pdfTable1);
                        pdfDoc.Add(pdfTable2);
                        pdfDoc.Add(p5);
                        pdfDoc.Add(pdfTable4);
                        pdfDoc.Add(p6);
                        pdfDoc.Add(paragraphTable2);
                        //pdfDoc.Add(pdfTable4);
                        //pdfDoc.Add(table);
                        // pdfDoc.Add(pdfTableBlank);
                        // pdfDoc.Add(new Chunk("\n"));
                        //pdfDoc.Add(jpg);
                        pdfDoc.Add(paragraphTable1);
                        pdfDoc.Add(pdfTable3);
                        pdfDoc.Add(p6);
                        pdfDoc.Add(pdfTableBottom);
                        pdfDoc.Add(p6);
                        pdfDoc.Add(pdfTableFooter);
                        pdfDoc.NewPage();
                      //  pdfDoc.Add(tablex);
                        #endregion
                        // pdfDoc.Add(jpg);
                        //pdfDoc.Add(pdfTable2);
                        pdfDoc.Close();
                        stream.Close();
                    }
                    #endregion
                    #region Display PDF
                    // System.Diagnostics.Process.Start(folderPath + "\\" +strFileName);
                    var p = new Process();
                    p.StartInfo = new ProcessStartInfo(folderPath + "\\" + strFileName)
                    {
                        UseShellExecute = true
                    };
                    p.Start();
                    #endregion

                    #endregion

                    txtName1.Text = "";
                    txtGSTIN1.Text = "";
                    txtState1.Text = "";
                    txtAddress1.Text = "";
                    txtDetailShipped.Text = "";
                    txtTransMode.Text = "";
                    txtVehicleNo.Text = "";
                    txtName2.Text = "";
                    txtAddress2.Text = "";
                    txtGSTIN2.Text = "";
                    txtState2.Text = "";
                    txtSearchProduct.Text = "";
                    txtProductName.Text = "";
                    txtInventory.Text = "";
                    txtRate.Text = "";
                    TxtQty.Text = "";
                    txtSubTotal.Text = "";
                    // txtDiscount.Text = "0";
                    txtIGST.Text = "";
                    txtCGST.Text = "";
                    txtSGST.Text = "";
                    txtGrandTotal.Text = "";
                    txtTotalTaxAmount.Text = "";
                    //txtReturnAmount.Text = "0";

                }
                else
                {
                    //Transaction Failed
                    MessageBox.Show("Transaction Failed");
                }
            }

        }
       
        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void lblEmail_Click(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void pSalesboxClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }

}
