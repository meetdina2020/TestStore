﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnyStore.BLL
{
    class transactionsBLL
    {
        public int id { get; set; }
        public string type { get; set; }
        public int dea_cust_id { get; set; }
        public decimal grandTotal { get; set; }
        public DateTime transaction_date { get; set; }
        public decimal tax { get; set; }
        public decimal discount { get; set; }
        public int added_by { get; set; }

        public DateTime invoice_date { get; set; }
        public string name1 { get; set; }
        public string address1 { get; set; }
        public string gstin1 { get; set; }
        public string state1 { get; set; }
        public string state_code1 { get; set; }
        public string consignee_shipped_to { get; set; }
        public string transportation_mode { get; set; }

        public string vehicle_no { get; set; }
        public string name2 { get; set; }
        public string address2 { get; set; }
        public string gstin2 { get; set; }
        public string state2 { get; set; }

        public string state_code2 { get; set; }
        public DataTable transactionDetails { get; set; }

    }
}
