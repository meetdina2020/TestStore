﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnyStore.BLL
{
    class GSTBLL
    {
        public decimal cgst { get; set; }
        public decimal sgst { get; set; }
        public decimal igst { get; set; }

    }
}
